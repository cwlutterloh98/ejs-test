# Clark State ERM App
An application made for Clark State Nursing Program

## Installation
Clone this repository or download it.
CD to the folder where you cloned the repository.
Open your command terminal and type [npm install] to install node modules.

## Usage
To start
$ node app.js

Then visit _http://localhost:3000/ in your browser.

To close
Ctrl-C to terminate.

## INSTALL SCSS
OPEN GITBASH IN THE ROOT DIRECTORY AND TYPE
npm install scss

## INSTALL SCSS
OPEN GITBASH IN THE ROOT DIRECTORY AND TYPE
sass --watch scss/app.scss public/css/styles.css

